#include "lfr_controller.h"

int main() {
#if MODE == SIMPLE_CTRL    
    LFRController ctrl(Simple_Mode);
    ctrl.simple_ctrl();
#elif MODE == PID_MODE
    LFRController ctrl(PID_Mode);
    ctrl.pid_ctrl();
#elif MODE == OP_PID_MODE    
    LFRController ctrl(PID_Opt_Mode);
    ctrl.pid_ctrl_opt();
#elif MODE == TEST_MOVES
    LFRController ctrl(Test_Mode);
    ctrl.test_moves();
#elif MODE == TEST_SENSOR_READING
    LFRController ctrl(Test_Mode);
    ctrl.test_sensors_reading();
#endif    
}