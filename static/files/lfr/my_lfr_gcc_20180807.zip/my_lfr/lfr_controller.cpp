#include "lfr_controller.h"

LFRController::LFRController(RunMode mode) 
    : button_(p21), left_led_(LED3), right_led_(LED1), mode_(mode), 
      pos_mod_(On_Track), nr_of_off_track_(0) {
    // if button is not pressed, it returns high (1)
    button_.mode(PullUp);
    m3pi_.locate(0,0);
    // mode
    m3pi_.printf("RoboCalc");
    
    m3pi_.locate(0,1);
    // mode
    m3pi_.printf("%02d.%d.%d.%d", VERSION, MODE, SPEED_LEVEL, OFF_TRACK_SAFE_LVL);
    /*if(mode == Test_Mode) { 
        m3pi_.printf("TestV0.1");
    } else if (mode == Simple_Mode) {
        m3pi_.printf("LFR-V0.1");
    } else if (mode == PID_Mode) {
        m3pi_.printf("PID-V0.1");
    } else if (mode == PID_Opt_Mode) {
        // PID2V0.2 - full speed (127)
        // PID2V021 - reduced speed at 85 instead of 127
        m3pi_.printf("PID2V021");
    } else {
        m3pi_.printf("Wrong");
    }*/

    wait(2.0);
    m3pi_.sensor_auto_calibrate();
}
#if MODE == SIMPLE_CTRL
void LFRController::simple_ctrl() {    
    while (mode_ == Simple_Mode) {
    
        // -1.0 is far left, 1.0 is far right, 0.0 in the middle
        float position_of_line = m3pi_.line_position();
        
        // Line is far right, slow the right motor
        if(position_of_line > FAR_FROM_CENTER) {
            m3pi_.right_forward(NORMAL_SPEED-2*CORRECTION);
            m3pi_.left_forward(NORMAL_SPEED);
            left_led_ = 1;
            right_led_ = 0;
        }
        // Line is more than the threshold to the right, slow the right motor
        else if (position_of_line > THRESHOLD && position_of_line <= FAR_FROM_CENTER) {
            m3pi_.right_forward(NORMAL_SPEED-CORRECTION);
            m3pi_.left_forward(NORMAL_SPEED);
            left_led_ = 1;
            right_led_ = 0;
        }
        // Line is more than 50% to the left, slow the left motor
        else if (position_of_line < -FAR_FROM_CENTER) {
            m3pi_.left_forward(NORMAL_SPEED-2*CORRECTION);
            m3pi_.right_forward(NORMAL_SPEED);
            right_led_ = 1;
            left_led_ = 0;
        }
        // Line is more than 50% to the left, slow the left motor
        else if (position_of_line < -THRESHOLD && position_of_line >= -FAR_FROM_CENTER) {
            m3pi_.left_forward(NORMAL_SPEED-CORRECTION);
            m3pi_.right_forward(NORMAL_SPEED);
            right_led_ = 1;
            left_led_ = 0;
        }
        
        // Line is in the middle
        else {
            m3pi_.forward(NORMAL_SPEED);
            left_led_ = 1;
            right_led_ = 1;
        }
        
        m3pi_.locate(0,0);
        m3pi_.printf("pos:%.2f",position_of_line);
    }
}
#elif MODE == PID_MODE
void LFRController::pid_ctrl() {
    int last_err = 0;
    int pos, err;
    long int_err = 0;
    int delta_speed, left_speed, right_speed, move_speed;

#ifdef OFF_TRACK
    int num_of_out_track = 0;
#endif 
        
    while (mode_ == PID_Mode) {
#ifdef OFF_TRACK
        if(out_of_track())
        {
            num_of_out_track++;
        }
        else
        {
            num_of_out_track = 0;
            right_led_ = 0;
            left_led_ = 0;
        }
    
        // if off track, then turn around and move again
        if(num_of_out_track > OFF_TRACK_COUNT)
        {
            turn_around(true, 180);
            m3pi_.forward(TURN_AROUND_SPEED);
            num_of_out_track = 0;
            right_led_ = 1;
            left_led_ = 0;
        }
#endif        
        pos = m3pi_.calib_line_position();
        // error
        err = pos - LINE_POS_CENTER;
        // integral error
        int_err += err;
               
        delta_speed = Kp * err + Ki * int_err + Kd * (err - last_err);
        last_err = err;

#if 1
        move_speed = MAX_SPEED;
        // cap the maximum speed difference between two wheels
        if (delta_speed > MAX_DELTA_SPEED ) 
        {
            delta_speed = MAX_DELTA_SPEED; 
            move_speed = TURN_SPEED;
        }
            
        if (delta_speed < -MAX_DELTA_SPEED )
        { 
            delta_speed = -MAX_DELTA_SPEED;
            move_speed = TURN_SPEED;
        }
        
        // slow down one side and maintain the speed of another side
        if (delta_speed >= 0)
        {
            right_speed = move_speed - delta_speed;
            left_speed = move_speed;
        }
        else 
        {
            right_speed = move_speed;
            left_speed = move_speed + delta_speed;
        }
#endif 
        
#if 0    
        // this method supposes the robot doesn't run at the top speed on a straight line
        // Kp = 0.05, Kd = 1.5, Ki = 0 is a not bad combination for this method
        right_speed = LINE_SPEED - delta_speed;
        left_speed = LINE_SPEED + delta_speed;
  
#endif            

        if (right_speed > MAX_SPEED ) 
            right_speed = MAX_SPEED; 
        if (left_speed > MAX_SPEED ) 
            left_speed = MAX_SPEED;
        if (right_speed < 0) 
            right_speed = 0; 
        if (left_speed < 0) 
            left_speed = 0;
            
        // set motor speed
        m3pi_.left_forward(left_speed);
        m3pi_.right_forward(right_speed);
    }
}
#elif MODE == OP_PID_MODE
// reference implementation of PID: optimization of PID Control for High Speed Line Tracking Robots
void LFRController::pid_ctrl_opt() {
    int last_err = 0;
    int pos, err;
    // keep lastest INT_LAST_NUMS errors
    int last_int_errs[INT_LAST_NUMS];
    // index of oldest error
    int oldest_int_err_index = 0;
    // integral error
    long int_err = 0;
    // accumulated errors for speed adjusting
    long accm_err = 0;
    
    float delta_speed, adj_speed, move_speed;
    float left_speed, right_speed;
    
    // initialize last_int_err
    int i;
    for (i = 0; i < INT_LAST_NUMS; i++)
        last_int_errs[i] = 0;

    while (mode_ == PID_Opt_Mode) {
        // check if off track
        read_sensors();
        
        if (pos_mod_ == Off_Track && mode_ == Error_Mode)
        {
            m3pi_.stop();
            m3pi_.locate(0,0);
            m3pi_.printf("Off Track");
            break;
        }
        else
        {
            pos = cur_pos_;
        }
        
        // if the robot is far to left or right, rotate robot back to track
        if(pos < LINE_POS_FAR_LEFT1) 
        {
            // far to right, then rotate left motor backwards
            m3pi_.left_backward(SHARP_CURVE_REV_SPEED);
            continue;
        }
        else if(pos > LINE_POS_FAR_RIGHT1)
        {
            // far to left, then rotate right motor backwards
            m3pi_.right_backward(SHARP_CURVE_REV_SPEED);
            continue;
        }
        else
        {
        }
        
        // error
        err = pos - LINE_POS_CENTER;
        // integral error, sum up last INT_LAST_NUMS errors
        // 1. put new error into the place of oldest 
        last_int_errs[oldest_int_err_index++] = err;
        // 2. update oldest_int_err_index, round to zero when reaching INT_LAST_NUMS - 1
        if (oldest_int_err_index >= INT_LAST_NUMS)
            oldest_int_err_index = 0;
        // 3. sum up
        int_err = 0;
        accm_err = 0;
        for (i = 0; i < INT_LAST_NUMS; i++) {
            int_err += last_int_errs[i];
            accm_err += (last_int_errs[i] >= 0) ? last_int_errs[i]:(-last_int_errs[i]);
        }
               
        delta_speed = (Kp * err + Ki * int_err + Kd * (err - last_err));
        adj_speed = (Ksr * accm_err);
        last_err = err;
        
        move_speed = MAX_SPEED;
        
        // slow down one side and maintain the speed of another side
        if (delta_speed >= 0)
        {
            right_speed = move_speed - delta_speed - adj_speed;
            left_speed = move_speed - adj_speed;
        }
        else 
        {
            right_speed = move_speed - adj_speed;
            left_speed = move_speed + delta_speed - adj_speed;
        }         
        
        if (right_speed > MAX_SPEED)
            right_speed = MAX_SPEED;
        
        if (left_speed > MAX_SPEED)
            left_speed = MAX_SPEED;

        if (right_speed < MAX_REV_SPEED)
            right_speed = MAX_REV_SPEED; 
        if (left_speed < MAX_REV_SPEED)
            left_speed = MAX_REV_SPEED;
        
        // set motor speed
        m3pi_.left_speed((int8_t)left_speed);
        m3pi_.right_speed((int8_t)right_speed);
    }
}
#elif MODE == TEST_MOVES
void LFRController::test_moves() {
    while (mode_ == Test_Mode) {
        /* test move functions */
        left_led_ = 1;
        right_led_ = 1;
        m3pi_.stop();
        // left forward only
        m3pi_.left_forward(30);
        m3pi_.right_forward(0);
        wait(5.0);
        // left backward only
        m3pi_.left_backward(30);
        wait(5.0);
        // right forward only
        m3pi_.left_backward(0);
        m3pi_.right_forward(30);
        wait(5.0);
        // right backward only
        m3pi_.right_backward(30);
        wait(5.0);
        // move forward
        m3pi_.left_forward(30);
        m3pi_.right_forward(30);
        wait(5.0);
        // anti-clockwise rotation (left rotation)
        m3pi_.left_backward(30);
        m3pi_.right_forward(30);
        wait(5.0);
        // clockwise rotation (right rotation)
        m3pi_.right_backward(30);
        m3pi_.left_forward(30);
        wait(5.0);
        // move backward
        m3pi_.left_backward(30);
        m3pi_.right_backward(30);
        left_led_ = 0;
        right_led_ = 0;
        wait(5.0);
    }
}

#elif MODE == TEST_SENSOR_READING
void LFRController::test_sensors_reading() {
    unsigned short val[5] = {0, 0, 0, 0, 0};
    
    while(mode_ == Test_Mode)
    {
        m3pi_.calib_sensors_value(val);
    
        m3pi_.locate(0,0);
        m3pi_.printf("%02d,%02d,%02d",val[0],val[1],val[2]);
        m3pi_.locate(0,1);
        m3pi_.printf("%03d,%03d ",val[3],val[4]);
        wait(3.0);
    }
}
#endif    

/**
 * if all five sensors' reading are less than a threshold, we regard the robot 
 * is off track.
 */
bool LFRController::out_of_track()
{
    unsigned short val[5] = {0, 0, 0, 0, 0};
    
    m3pi_.calib_sensors_value(val);
    
    if (val[0] <= CALIB_SENSOR_MIN_THRESHOLD &&
        val[1] <= CALIB_SENSOR_MIN_THRESHOLD &&
        val[2] <= CALIB_SENSOR_MIN_THRESHOLD &&
        val[3] <= CALIB_SENSOR_MIN_THRESHOLD &&
        val[4] <= CALIB_SENSOR_MIN_THRESHOLD)
    {
        return true;
    }

    return false;                  
}

/** turn around */
void LFRController::turn_around(bool left, int angle)
{
    m3pi_.stop();
    wait(0.5);
    /* m3pi_.locate(0,0);
    m3pi_.printf("Turn Back"); */
    if(left)
        m3pi_.left_rotate(TURN_AROUND_SPEED);
    else
        m3pi_.right_rotate(TURN_AROUND_SPEED);
    wait(angle*TURN_AROUND_TIME/180);
    m3pi_.stop();
}

void LFRController::printToLCD(char *text, int line)
{
    m3pi_.locate(0, (line == 0)?0:1);
    m3pi_.printf(text);
}

/**
 * Read five sensors' values and calculate weighed position, and determine position mode 
 * Reference: 
 *  https://github.com/sdale28/Pololu-3pi-Library/blob/master/libraries/Pololu3piLib/src/PololuQTRSensors.cpp
 */

void LFRController::read_sensors()
{
    unsigned short val[5] = {0, 0, 0, 0, 0};
    unsigned char i;
    
    unsigned long weighted_sum = 0;
    unsigned int sum = 0;
    
    //  A bitmap to record which sensor sees the line
    unsigned char on_line = 0;

    m3pi_.calib_sensors_value(val);
    
    for(i = 0; i < 5; i++)
    {
        int v = val[i];
        
        // 200 should be enough for white ground and black line
        // but in my office, the desk table surface is not white (like real wood mark)
        // after a calibration in a black line, I have tested the sensors on the table
        // surface could up to 280. So probably better to set it to 300
        if (v > CALIB_SENSOR_MIN_THRESHOLD)
            on_line |= (1 << i);
            
        if(v > 50) 
        {
            weighted_sum += (long)(v) * (i * 1000);
            sum += v;
        }
    }
    
    // doesn't see the line
    if(!on_line)
    {
        pos_mod_ = Off_Track;
        
        left_led_ = 1;
        
        // increate the number of off-track
        nr_of_off_track_++;
        
#ifdef WEIGHTED_SUM
        // use the average weighted sum even on_line is false
        cur_pos_ = weighted_sum / sum;
#else
        // If the last position is to the left of center, return 0.
        if(cur_pos_ < LINE_POS_CENTER)
            cur_pos_ = LINE_POS_FAR_LEFT;
        // If the last position is to the right of center, return the max.
        else
            cur_pos_ = LINE_POS_FAR_RIGHT;
#endif        
        // doesn't see the line for many times, just regard it as off track, so 
        //  stop the robot to avoid further problem
        if(nr_of_off_track_ > OFF_TRACK_COUNT)
        {
            right_led_ = 1;
            mode_ = Error_Mode;
        }
    }
    else 
    {
        left_led_ = 0;
        right_led_ = 0;
    
        // clear
        nr_of_off_track_ = 0;        

        // every sensor sees the line, might be a cross road or T-end
        if(on_line == 0b11111)
        {
            pos_mod_ = T_Junc;
        }
        else
        {
            pos_mod_ = On_Track;
        }
        
        cur_pos_ = weighted_sum / sum;
    }    
}