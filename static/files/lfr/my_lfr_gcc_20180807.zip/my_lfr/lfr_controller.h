/**
 * Controller high-level functions: such as modes and algorithms
 *  
 *  Notes: need to config these macros to change mode, speed, and off-track protection
 *      - MODE
 *      - OFF_TRACK_SAFE_LVL
 *      - SPEED_LEVEL
 */
#ifndef LFR_CONTROLLER_H
#define LFR_CONTROLLER_H

#include "mbed.h"
#include "platform.h"
#include "m3pi.h"

#define VERSION                 1
/*******************************************************************************
 *          Run mode                                                           *
 *******************************************************************************/
#define TEST_MOVES              0x1
#define TEST_SENSOR_READING     0x2
#define SIMPLE_CTRL             0x3
#define PID_MODE                0x4
#define OP_PID_MODE             0x5

// Choose a mode to run
#define MODE                    OP_PID_MODE

/*******************************************************************************
 *          Position Related                                                      *
 *******************************************************************************/
// line position
#define LINE_POS_CENTER     2000
#define LINE_POS_FAR_LEFT   0
#define LINE_POS_FAR_RIGHT  4000
#define LINE_POS_FAR_LEFT1  50
#define LINE_POS_FAR_RIGHT1 3950

// maximum raw sensor reading
#define RAW_SENSOR_MAX      2000
// maximum calibrated sensor reading
#define CALIB_SENSOR_MAX    1000
// minimum sensor reading to establish the black line is under the sensor
// this is used to filter various surface (such as for desktop surface without 
// black line, it could reach up to 300)
#define CALIB_SENSOR_MIN_THRESHOLD 400

/*******************************************************************************
 *          Speed Related                                                      *
 *******************************************************************************/
// maximum configurable speed
#define MAX_CONF_SPEED           (127)
// turn around speed
#define TURN_AROUND_SPEED   20
// turn around time (speed and time determine the stop angle) (20 and 0.85 are matched)
#define TURN_AROUND_TIME    0.85

// speed from low to high
#define SPEED_LVL_1         0x1
#define SPEED_LVL_2         0x2
#define SPEED_LVL_3         0x3
#define SPEED_LVL_4         0x4
#define SPEED_LVL_5         0x5

#define SPEED_LEVEL         SPEED_LVL_3

#if SPEED_LEVEL == SPEED_LVL_1
    #define MAX_SPEED               (MAX_CONF_SPEED/5)
    #define SHARP_CURVE_REV_SPEED   (0)
#elif SPEED_LEVEL == SPEED_LVL_2
    #define MAX_SPEED               (MAX_CONF_SPEED*2/5)
    #define SHARP_CURVE_REV_SPEED   (5)
#elif SPEED_LEVEL == SPEED_LVL_3
    #define MAX_SPEED               (MAX_CONF_SPEED*3/5)  
    #define SHARP_CURVE_REV_SPEED   (10)
#elif SPEED_LEVEL == SPEED_LVL_4
    #define MAX_SPEED               (MAX_CONF_SPEED*4/5)
    #define SHARP_CURVE_REV_SPEED   (20)
#elif SPEED_LEVEL == SPEED_LVL_5
    #define MAX_SPEED               (MAX_CONF_SPEED)
    #define SHARP_CURVE_REV_SPEED   (30)
#endif           

/*******************************************************************************
 *          Off Track Prorection                                               *
 *******************************************************************************/
// the level of off track protection

// absolutely safe mode: if detected off-track once, then stop
// therefore, speed should be low. otherwise, it is very easy to over-shot, then 
// stop
#define ABS_SAFE_MODE          0x1
// relatively safe: off-track for a small amount of time is OK.
#define REL_SAFE_MODE          0x2
// aggressive: still carry on even off-track, and only stop if always off-track 
// for relatively large amount of time
#define AGGRESSIVE_MODE        0x3

#define OFF_TRACK_SAFE_LVL     REL_SAFE_MODE

#if OFF_TRACK_SAFE_LVL == ABS_SAFE_MODE
    #define OFF_TRACK
    // continuously off track for OFF_TRACK_COUNT loops will be regarded as off
    // track and not possible to back to track, so turn around
    #define OFF_TRACK_COUNT     30
    #undef CALIB_SENSOR_MIN_THRESHOLD
    #define CALIB_SENSOR_MIN_THRESHOLD 300
#elif OFF_TRACK_SAFE_LVL == REL_SAFE_MODE
    #define OFF_TRACK
    // continuously off track for OFF_TRACK_COUNT loops will be regarded as off
    // track and not possible to back to track, so turn around
    #define OFF_TRACK_COUNT     150
#elif OFF_TRACK_SAFE_LVL == AGGRESSIVE_MODE
    #define OFF_TRACK
    // continuously off track for OFF_TRACK_COUNT loops will be regarded as off
    // track and not possible to back to track, so turn around
    #define OFF_TRACK_COUNT     250
#endif    

/*******************************************************************************
 *          Mode related parameters                                            *
 *******************************************************************************/
#if MODE == SIMPLE_CTRL
    /////////////////////////// for simple mode /////////////////////////
    #define NORMAL_SPEED 30 // 60 of 127
    #define CORRECTION  (NORMAL_SPEED/3) // 10 of 127
    #define THRESHOLD 0.5
    // if the line position is less than -0.95 or larger than 0.95, it is far from center
    #define FAR_FROM_CENTER  0.95

#elif MODE == PID_MODE
    /////////////////////////// for PID mode /////////////////////////
    // smaller, and then control will response to setpoint error very slow => very easily out of track
    // too big means even on a straight line, the robot will swing forward
    #define Kp              0.08 // according to DSE results
    // derivative improves cross-track error and makes the robot more close to the centre of the line
    #define Kd              1.0 // 0.1
    
    #define Ki              0.002
    
    // when it's a straight line
    #define LINE_SPEED  85
    // turn speed should be lower when the track has sharp corner and bigger without
    // sharp corner
    #define TURN_SPEED  85
    // max delta speed
    #define MAX_DELTA_SPEED     100

#elif MODE == OP_PID_MODE
    /////////////////////////// for optimised PID mode /////////////////////////
    // smaller, and then control will response to setpoint error very slow => very easily out of track
    // too big means even on a straight line, the robot will swing forward
    #define Kp              0.08 // according to DSE results
    // derivative improves cross-track error and makes the robot more close to the centre of the line
    #define Kd              1.0 // 0.1
    #define Ki              0.002
    // only last numbers of error values are taken into account
    #define INT_LAST_NUMS   10    
    // constant to reduce speed of both motors
    #define Ksr             0.0055
    // maximum reverse speed
    #define MAX_REV_SPEED   (-20)
#endif

// use explicit weighted sum instead of line position from 3pi directly
#define WEIGHTED_SUM

typedef enum {
    Test_Mode, 
    Simple_Mode, 
    PID_Mode, 
    PID_Opt_Mode,
    Error_Mode
} RunMode;

typedef enum {
    On_Track,  // normal postion, robot is following the line
    Off_Track, // off track, all sensors return 0 (no black line detected)
    T_Junc,    // like a T junction, all sensors return maximum value (detect a black line)
    Pos_Err
} RobotPosEnum;

class LFRController {
private :
    m3pi m3pi_;
    DigitalIn button_;
    DigitalOut left_led_;
    DigitalOut right_led_;
    
    RunMode mode_;
    RobotPosEnum pos_mod_;
    int cur_pos_;
    int nr_of_off_track_;
    
public:
    LFRController(RunMode mode);
    
#if MODE == SIMPLE_CTRL    
    /** Simple LFR controller */
    void simple_ctrl();
#elif MODE == PID_MODE
    /** PID controller */
    void pid_ctrl();
#elif MODE == OP_PID_MODE    
    void pid_ctrl_opt();
#elif MODE == TEST_MOVES
    void test_moves();
#elif MODE == TEST_SENSOR_READING
    /** 
     * test sensor reading 
     */
    void test_sensors_reading();
#endif    
    /** out_of_track: no black line detected */
    bool out_of_track();
    /** */
    bool sharp_corner();
    /** turn around */
    void turn_around(bool left, int angle);
    /** print message on lcd */
    void printToLCD(char *text, int line); 
    void read_sensors();
};

#endif