/**
 * The m3pi class encapsulates serial commands to provide necessary functions to 
 operator m3pi, such as move forward and backward, calibration etc.
 */
 
#include "mbed.h"
#include "m3pi.h"

m3pi::m3pi(PinName nrst, PinName tx, PinName rx) :  Stream("m3pi"), _nrst(nrst), _ser(tx, rx)  {
    _ser.baud(115200);
    reset();
}

m3pi::m3pi() :  Stream("m3pi"), _nrst(p23), _ser(p9, p10)  {
    _ser.baud(115200);
    reset();
}


void m3pi::reset () {
    _nrst = 0;
    wait (0.01);
    _nrst = 1;
    wait (0.1);
}

void m3pi::forward (byte speed) {
    left_forward(speed);
    right_forward(speed);
}

void m3pi::backward (byte speed) {
    left_backward(speed);
    right_backward(speed);
}

void m3pi::left_rotate (byte speed) {
    left_backward(speed);
    right_forward(speed);
}

void m3pi::right_rotate (byte speed) {
    right_backward(speed);
    left_forward(speed);
}

void m3pi::stop (void) {
    left_forward(0);
    right_forward(0);
}

float m3pi::battery() {
    _ser.putc(BATTERY_MILLIVOLTS);
    char lowbyte = _ser.getc();
    char hibyte  = _ser.getc();
    float v = ((lowbyte + (hibyte << 8))/1000.0);
    return(v);
}

float m3pi::line_position() {
    int pos = 0;
    _ser.putc(LINE_POSITION);
    pos = _ser.getc();
    pos += _ser.getc() << 8;

 /*  The value, which is sent back as a two-byte integer, is 0 when the line is 
 *  under sensor PC0 or farther to the left, 1000 when the line is directly under 
 *  sensor PC1, up to 4000 when it is under sensor PC4 or farther to the right. 
 *  See Section 19 of of the Pololu AVR Library Command Reference for the formula 
 *  used to estimate position.    
 */
    float fpos = ((float)pos - 2048.0)/2048.0;
    return(fpos);
}

char m3pi::sensor_auto_calibrate() {
    _ser.putc(AUTO_CLB);
    return(_ser.getc());
}

void m3pi::calibrate(void) {
    _ser.putc(CALIBRATE);
}

void m3pi::reset_calibration() {
    _ser.putc(RESET_CLB);
}

void m3pi::PID_start(int max_speed, int a, int b, int c, int d) {
    _ser.putc(max_speed);
    _ser.putc(a);
    _ser.putc(b);
    _ser.putc(c);
    _ser.putc(d);
}

void m3pi::PID_stop() {
    _ser.putc(STOP_PID);
}

float m3pi::pot_voltage(void) {
    int volt = 0;
    _ser.putc(TRIMPOT);
    volt = _ser.getc();
    volt += _ser.getc() << 8;
    return(volt);
}

void m3pi::leds(int val) {

    BusOut _leds(p20,p19,p18,p17,p16,p15,p14,p13);
    _leds = val;
}

void m3pi::locate(int x, int y) {
    _ser.putc(GOTO_XY_LCD);
    _ser.putc(x);
    _ser.putc(y);
}

void m3pi::cls(void) {
    _ser.putc(CLEAR_LCD);
}

int m3pi::print (char* text, int length) {
    _ser.putc(PRINT);  
    _ser.putc(length);       
    for (int i = 0 ; i < length ; i++) {
        _ser.putc(text[i]); 
    }
    return(0);
}

int m3pi::_putc (int c) {
    _ser.putc(PRINT);  
    _ser.putc(0x1);       
    _ser.putc(c);         
    wait (0.001);
    return(c);
}

int m3pi::_getc (void) {
    char r = 0;
    return(r);
}

int m3pi::putc (int c) {
    return(_ser.putc(c));
}

int m3pi::getc (void) {
    return(_ser.getc());
}


/** Read back calibrated sensor values of 5 sensors
 *
 */
void m3pi::calib_sensors_value (unsigned short val[]) {
    _ser.putc(CLB_SENSOR);
    
    for (int i = 0; i < 5; i++) {
        val[i] = _ser.getc();
        val[i] |= _ser.getc() << 8;
    }
}

int m3pi::calib_line_position () {
    int pos = 0;
    _ser.putc(LINE_POSITION);
    pos = _ser.getc();
    pos += _ser.getc() << 8;

    return (pos);    
}

void m3pi::left_forward(byte speed) {
    _ser.putc(M1_FORWARD); 
    _ser.putc(speed); 
}

void m3pi::left_backward(byte speed)  {
    _ser.putc(M1_BACKWARD); 
    _ser.putc(speed); 
}

void m3pi::right_forward(byte speed) {
    _ser.putc(M2_FORWARD); 
    _ser.putc(speed); 
}
                            
void m3pi::right_backward(byte speed) {
    _ser.putc(M2_BACKWARD); 
    _ser.putc(speed); 
}

void m3pi::left_speed (int8_t speed)
{
    if (speed >= 0)
    {
        left_forward(speed);
    }
    else
    {
        left_backward(-speed);
    }
}
void m3pi::right_speed (int8_t speed)
{
    if (speed >= 0)
    {
        right_forward(speed);
    }
    else
    {
        right_backward(-speed);
    }
}
