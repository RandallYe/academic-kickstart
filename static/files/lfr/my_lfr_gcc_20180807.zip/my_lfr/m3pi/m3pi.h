/**
 * The m3pi class encapsulates serial commands to provide necessary functions to 
 operator m3pi, such as move forward and backward, calibration etc.
 */
#ifndef M3PI_H
#define M3PI_H

#include "mbed.h"
#include "platform.h"

#ifdef MBED_RPC
#include "rpc.h"
#endif

// Serial slave program 
// commands defined at https://www.pololu.com/docs/0J21/10.a

// signature
#define SIGN 0x81
#define RAW_SENSOR 0x86
// read back calibrated 5 sensor values in 10 bytes, in the range 0-1000
#define CLB_SENSOR 0x87
#define TRIMPOT 0xB0
#define BATTERY_MILLIVOLTS 0xB1
// play music
#define PLAY 0xB3
#define CALIBRATE 0xB4
#define RESET_CLB 0xB5
#define LINE_POSITION 0xB6
#define CLEAR_LCD 0xB7
#define PRINT 0xB8
#define GOTO_XY_LCD 0xB9
#define AUTO_CLB 0xBA
#define SET_PID 0xBB
#define STOP_PID 0xBC
#define M1_FORWARD 0xC1
#define M1_BACKWARD 0xC2
#define M2_FORWARD 0xC5
#define M2_BACKWARD 0xC6

typedef unsigned char byte;


class m3pi :  public Stream {

public:

    /** Create the m3pi object connected to the default pins
     *
     * @param nrst GPIO pin used for reset. Default is p23
     * @param tx Serial transmit pin. Default is p9
     * @param rx Serial receive pin. Default is p10
     */
    m3pi();


    /** Create the m3pi object connected to the default pins
     *
     */
    m3pi(PinName nrst, PinName tx, PinName rx);



    /** Force a hardware reset of the 3pi
     */
    void reset (void);

    // M1 - left, M2 - right
    // speed: 0 - 127
    void left_forward (byte speed);                            
    void left_backward (byte speed);
    void right_forward (byte speed);
    void right_backward (byte speed);
    
    // set speed for M1 and M2
    // Positive speed - forward
    // Negative speed - backward
    void left_speed (int8_t speed);
    void right_speed (int8_t speed);
    
    /** Drive both motors forward as the same speed
     *
     * @param speed A normalised number 0 - 1.0 represents the full range.
     */
    void forward (byte speed);

    /** Drive both motors backward as the same speed
     *
     * @param speed A normalised number 0 - 1.0 represents the full range.
     */
    void backward (byte speed);

    /** Drive left motor backwards and right motor forwards at the same speed to turn on the spot
     *
     * @param speed A normalised number 0 - 1.0 represents the full range.
     */
    void left_rotate (byte speed);

    /** Drive left motor forward and right motor backwards at the same speed to turn on the spot
     * @param speed A normalised number 0 - 1.0 represents the full range.
     */
    void right_rotate (byte speed);

    /** Stop both motors
     *
     */
    void stop (void);

    /** Read the voltage of the potentiometer on the 3pi
     * @returns voltage as a float
     *
     */
    float pot_voltage(void);

    /** Read the battery voltage on the 3pi
     * @returns battery voltage as a float
     */
    float battery(void);

    /** Read the position of the detected line
     * @returns position as A normalised number -1.0 - 1.0 represents the full range.
     *  -1.0 means line is on the left, or the line has been lost
     *   0.0 means the line is in the middle
     *   1.0 means the line is on the right
     */
    float line_position (void);


    /** Calibrate the sensors. This turns the robot left then right, looking for a line
     *
     */
    char sensor_auto_calibrate (void);

    /** Set calibration manually to the current settings.
     *
     */
    void calibrate(void);

    /** Clear the current calibration settings
     *
     */
    void reset_calibration (void);

    void PID_start(int max_speed, int a, int b, int c, int d);

    void PID_stop();

    /** Write to the 8 LEDs
     *
     * @param leds An 8 bit value to put on the LEDs
     */
    void leds(int val);

    /** Locate the cursor on the 8x2 LCD
     *
     * @param x The horizontal position, from 0 to 7
     * @param y The vertical position, from 0 to 1
     */
    void locate(int x, int y);

    /** Clear the LCD
     *
     */
    void cls(void);

    /** Send a character directly to the 3pi serial interface
     * @param c The character to send to the 3pi
     */
    int putc(int c);

    /** Receive a character directly to the 3pi serial interface
     * @returns c The character received from the 3pi
     */
    int getc();

    /** Send a string buffer to the 3pi serial interface
     * @param text A pointer to a char array
     * @param int The character to send to the 3pi
     */
    int print(char* text, int length);

    /** Read back calibrated sensor values of 5 sensors
     * Reads all five IR sensors and sends calibrated values as a sequence of 
     *  two-byte ints, in the range 0-1000 
     */
    void calib_sensors_value (unsigned short val[]);
    
    /**
     * Return calibrated line position (0-4000): 
     *  0 - far left, 2000 - center, 4000 - far right
     */
    int calib_line_position (void);
    
private :

    DigitalOut _nrst;
    Serial _ser;
    
    void motor (int motor, float speed);
    virtual int _putc(int c);
    virtual int _getc();

};

#endif